<?php 

session_start();
$_SESSION["isuser"]= true;